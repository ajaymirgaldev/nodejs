// require dependancies//
const fs = require('fs');
const convert = require('xml-js');
const { Parser } = require('json2csv');

//xml file and path
const xmlFile = "./xml/modul_01_Introduction.xml";

//Varibales //
var fields = ["OST"];
var ost_data= ["OST"];
var ts_data = ["\r\n","Transcript"];
var csvData = {};

//load xml file from directory
//TODO- do check if file exist on given path, also user has access permission //
var xml = require('fs').readFileSync(xmlFile, 'utf8');

//Convert xml in to JSON and Parse to JSON
var jsonOutput = JSON.parse(convert.xml2json(xml, {compact: true, spaces: 4}));

//Filter data// 

jsonOutput["modul"]["question"].forEach((elm, i) => {

    //Filter for OST // 
    //TODO - eliminate if condition while optimizing code//
    try {
        if(!elm["screentext"].length){
            ost_data.push(elm["screentext"]["_cdata"]);
        }else{
        // Filtering multipul entries 
            elm["screentext"].forEach((elm_i, j) => {
                ost_data.push(elm["screentext"][j]["_cdata"]);
            });
        }
    }catch{
        console.log("OST data not available.");
    }

    //Filtering Transscript data //
    if(elm["text"]){
        ts_data.push(elm["text"]["_cdata"]);
    }
});

//Filter Main text // 
try {
    jsonOutput["modul"]["meinText"]["mtext"].forEach((elm, i) => {
        //Filter for main text //
        ost_data.push(elm["_cdata"]);
    });
}catch{
    console.log("Main text is not available.");
}


//uniquify data //
ost_data = [...new Set(ost_data)];
ts_data = [...new Set(ts_data)];

//Mapping array data //
ost_data = ost_data.map(elm => new Array(elm));
ts_data = ts_data.map(elm => new Array(elm));

csvData = ost_data.concat(ts_data);

//
const parser = new Parser();
const csv = parser.parse(csvData, {fields});
var csvFilename = xmlFile.split("/").slice(-1)[0].split(".")[0]+".csv";

//Write file to directory
fs.writeFile("output/"+ csvFilename, csv, function(err) {
    if (err) throw err;
    console.log('file generated');
});


