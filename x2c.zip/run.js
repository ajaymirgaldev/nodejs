'use strict';

const fs = require('fs');
const config = require("./modules/loadConfig");
const x2c = require("./modules/x2c");

//Variables//


//
var configData = config.loadConfig("config.json");

//
x2c.loadXML(configData);