'use strict';

const http = require('http');
const fs = require('fs');
const convert = require('xml-js');
const { Parser } = require('json2csv');

//Varibales //
var fields;
var ost_data;
var ts_data;
var csvData;
var fileName;


exports.loadXML = function(configData = {}){

    //check for valid config Data has list of xml to load//
    if(!configData.hasOwnProperty("list_of_xmls")){
        console.log("config data is not valid");
        return;
    }

    //
    processX2C(configData);
}

let processX2C = (configData) => {
    //
    if(!configData["list_of_xmls"].length){
        console.log("List of xml files not found. config data is not valid");
        return;
    }

    //get list of xml to load //
    configData["list_of_xmls"].forEach((file, i) => {
        //  
        loadAndParseXML(file, configData);

    });    
}

//
var loadAndParseXML = (xmlFile, configData) => {
    
    //File name which is in process//
    fileName = xmlFile;

    //TODO- do check if file exist on given path, also user has access permission //
    //load xml file from directory
    try{
        var xml = require('fs').readFileSync(xmlFile, 'utf8');
    }catch(err){
        console.log("Xml file / folder not found "+xmlFile);
        return;
    }
    

    //Convert xml in to JSON and Parse to JSON
    try{
        var jsonOutput = JSON.parse(convert.xml2json(xml, {compact: true, spaces: 4}));
    }catch(err){
        console.log(xmlFile+" xml formate is not correct: "+err);
        return;
    }
    

    //Filter data// 
    filterData(jsonOutput, configData);
}

//
var filterData = (jsonOutput = {}, configData = {}) => {

    //reset aribales to default values//
    fields = ["OST"];
    ost_data= ["OST"];
    ts_data = ["\r\n","Transcript"];
    csvData = {};

    //Filter data// 
    //get list of nodes//
    jsonOutput["modul"]["question"].forEach((elm, i) => {
        try {
            if(!elm["screentext"].length){
                ost_data.push(elm["screentext"]["_cdata"]);
            }else{
            // Filtering multipul entries 
                elm["screentext"].forEach((elm_i, j) => {
                    ost_data.push(elm["screentext"][j]["_cdata"]);
                });
            }

            //
            if(elm["text"]){
                ts_data.push(elm["text"]["_cdata"]);
            }
        }catch{
            console.log("OST data not available.");
        }
    });

    //Filter Main text // 
    try {
        jsonOutput["modul"]["meinText"]["mtext"].forEach((elm, i) => {
            //Filter for main text //
            ost_data.push(elm["_cdata"]);
        });
    }catch{
        console.log("Main text is not available.");
    }

    //Filter captions//
    try {
        jsonOutput["modul"]["scene"].forEach((elm, i) => {
            
            //Filter for main text //
            elm["scenebutton"].forEach((elm_i, j) => {
                
                if(!elm_i["caption"]){}
                else{
                    ost_data.push(elm_i["caption"]["_cdata"]);
                }
            });
        });
    }catch{
      console.log("caption text is not available.");
    }

    //uniquify data //
    ost_data = [...new Set(ost_data)];
    ts_data = [...new Set(ts_data)];

    //Mapping array data //
    ost_data = ost_data.map(elm => new Array(elm));
    ts_data = ts_data.map(elm => new Array(elm));

    //CSV data //
    csvData = ost_data.concat(ts_data);

    //
    writeCSV(csvData);
} 

//Write csv file//
var writeCSV = (csvData) => {
    const parser = new Parser();
    const csv = parser.parse(csvData, {fields});
    var csvFilename = fileName.split("/").slice(-1)[0].split(".")[0]+".csv";
    
    //check and create csv output folder //
    var dir = './output';
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir);
    }

    //Write file to directory
    fs.writeFile("output/"+ csvFilename, csv, function(err) {
        if (err) throw err;
        console.log('file generated at '+"output/"+ csvFilename);
    });
}