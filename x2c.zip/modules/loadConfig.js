'use strict';

//
const fs = require('fs');

//
let configData;

exports.loadConfig = (f_name) => {
    //Load Config JSON//
    var rawdata = require('fs').readFileSync(f_name);
    configData = JSON.parse(rawdata);

    //config data //
    return configData;
} 

//
exports.getListOfXML = () => {
    if(!configData){
        console.log("Please load CONFIG json!");
        return;
    }

    //return list of xml to load//
    return configData.list_of_xmls;
}

//

